create database votaciones;
use votaciones;

insert into user ( email, contrasena, nombre, correo) value ('admin@gmail.com','123','admin', 'admin@gmai.com');

update user set id =  1 where id = 0;
