<?php

class Votos{

public $id;
public $candidatoid;
public $puesto;
public $votosc;
public $eleccionid;
public $votost;


public function __construct(){
}
}


?>