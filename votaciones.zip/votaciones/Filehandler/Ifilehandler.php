<?php

interface Ifilehandler {
    function CreateDirectory();
    function SaveFile($value);
    function ReadFile();
}
?>