
   <?php

include '../assets/layout/layoutadmi.php';
require_once '../user/auth.php';


?>   


<?php printHeader();?>