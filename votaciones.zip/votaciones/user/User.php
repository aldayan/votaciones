<?php

class User{

    public $id;
    public $email;
    public $contrasena;
    public $nombre;
    public $apellido;
    public $correo;

}

?>